<?php

namespace App\Http\Requests\API;

/**
 * @property-read string $order
 * @property-read string $sort
 */
class GenreFetchSongRequest extends Request
{
}
