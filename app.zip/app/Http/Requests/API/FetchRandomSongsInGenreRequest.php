<?php

namespace App\Http\Requests\API;

/**
 * @property-read string $genre
 * @property-read int $limit
 */
class FetchRandomSongsInGenreRequest extends Request
{
}
