<?php

namespace App\Http\Requests\API;

/**
 * @property-read string|null $pageToken
 */
class YouTubeSearchRequest extends Request
{
}
