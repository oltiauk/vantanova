<?php

namespace App\Http\Integrations\Lastfm\Contracts;

interface RequiresSignature
{
}
