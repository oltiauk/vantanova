<?php

namespace App\Exceptions;

use DomainException;

class OperationNotApplicableForSmartPlaylistException extends DomainException
{
}
