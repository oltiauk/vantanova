<?php

namespace App\Exceptions;

use DomainException;

class MediaBrowserNotSupportedException extends DomainException
{
}
