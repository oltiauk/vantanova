<?php

namespace App\Exceptions;

use DomainException;

class NotAPlaylistCollaboratorException extends DomainException
{
}
