<?php

namespace App\Exceptions;

use RuntimeException;

class InvitationNotFoundException extends RuntimeException
{
}
