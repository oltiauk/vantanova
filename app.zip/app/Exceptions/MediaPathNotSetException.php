<?php

namespace App\Exceptions;

use LogicException;

class MediaPathNotSetException extends LogicException
{
}
