<?php

namespace App\Exceptions;

use DomainException;

class LocalStorageRequiredException extends DomainException
{
}
