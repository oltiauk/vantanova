<?php

namespace App\Exceptions;

use RuntimeException;

class PlaylistCollaborationTokenExpiredException extends RuntimeException
{
}
