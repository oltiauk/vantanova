<?php

namespace App\Exceptions;

use Exception;

class CannotRemoveOwnerFromPlaylistException extends Exception
{
}
