<?php

namespace App\Enums;

enum DoctorResult
{
    case SUCCESS;
    case ERROR;
}
