<?php

namespace App\Services\Streamer\Adapters;

abstract class LocalStreamerAdapter implements StreamerAdapter
{
}
