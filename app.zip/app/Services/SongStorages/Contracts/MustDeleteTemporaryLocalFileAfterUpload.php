<?php

namespace App\Services\SongStorages\Contracts;

interface MustDeleteTemporaryLocalFileAfterUpload
{
}
