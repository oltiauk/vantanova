<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('label_watchlists', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id');
            $table->string('label');
            $table->string('normalized_label');
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->unique(['user_id', 'normalized_label']);
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });

        Schema::create('label_watchlist_searches', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id');
            $table->json('results')->nullable();
            $table->timestamp('last_executed_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedInteger('label_count')->default(0);
            $table->unsignedInteger('track_count')->default(0);
            $table->timestamps();

            $table->unique('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('label_watchlist_searches');
        Schema::dropIfExists('label_watchlists');
    }
};
