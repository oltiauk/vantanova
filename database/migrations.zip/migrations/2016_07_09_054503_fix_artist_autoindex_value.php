<?php

use Illuminate\Database\Migrations\Migration;

class FixArtistAutoindexValue extends Migration
{
    public function up(): void
    {
    }

    public function down(): void
    {
    }
}
