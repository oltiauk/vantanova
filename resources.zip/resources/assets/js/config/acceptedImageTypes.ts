export const acceptedImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif'] as const
