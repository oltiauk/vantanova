<template>
  <section>
    <h3 class="text-2xl font-thin flex place-content-between mb-5">
      <slot name="header" />
    </h3>
    <slot />
  </section>
</template>
