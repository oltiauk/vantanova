<template>
  <div>
    <h3 class="text-2xl mb-8 font-thin">
      <slot name="header" />
    </h3>

    <slot />
  </div>
</template>
