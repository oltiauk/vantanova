<template>
  <header class="skeleton screen-header expanded flex items-end relative content-stretch p-8">
    <aside class="w-[192px] aspect-square rounded-lg block mr-5 pulse" />

    <main class="flex flex-col items-start flex-1 gap-5">
      <h1 class="h-[4rem] w-4/5 pulse" />
      <p class="meta h-[1.2rem] w-2/5 pulse" />
      <p class="controls h-[2.5rem] rounded w-1/4 pulse" />
    </main>
  </header>
</template>
