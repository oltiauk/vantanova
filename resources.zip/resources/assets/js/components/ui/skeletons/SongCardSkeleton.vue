<template>
  <article class="skeleton flex gap-4 p-3 rounded items-center border border-k-border">
    <aside class="w-[48px] aspect-square rounded pulse" />
    <main class="flex items-start flex-1 gap-4">
      <div class="flex flex-1 flex-col gap-2">
        <h3 class="w-2/3 h-[1.2rem] pulse" />
        <p class="w-1/3 h-[1.2rem] pulse" />
      </div>
    </main>
  </article>
</template>
