<template>
  <article
    class="skeleton flex gap-4 px-6 py-5 !text-k-text-primary"
  >
    <aside class="flex-[0_0_128px]">
      <div class="pulse rounded-lg aspect-square" />
    </aside>
    <main class="flex-1 pt-3">
      <h3 class="pulse w-2/3 h-8" />
      <div class="mt-4">
        <div class="pulse w-full h-5 mb-2" />
        <div class="pulse w-2/3 h-5" />
        <div class="pulse w-1/3 h-5 mt-4" />
      </div>
    </main>
  </article>
</template>

<script lang="ts" setup>
</script>
