<template>
  <div class="min-h-full flex flex-col relative">
    <slot />
  </div>
</template>
