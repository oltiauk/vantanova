<template>
  <div class="p-6 overflow-auto">
    <slot />
  </div>
</template>
