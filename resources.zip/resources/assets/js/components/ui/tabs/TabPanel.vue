<template>
  <div role="tabpanel" tabindex="0">
    <slot />
  </div>
</template>
