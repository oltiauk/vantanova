<template>
  <nav class="overflow-auto border-b-[2px] border-b-white/10 px-6 py-0 flex gap-1 min-h-[41px]" role="tablist">
    <slot />
  </nav>
</template>
