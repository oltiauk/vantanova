<template>
  <span class="!opacity-50">
    <Icon :icon="faSquareUpRight" />
  </span>
</template>

<script lang="ts" setup>
import { faSquareUpRight } from '@fortawesome/free-solid-svg-icons'
</script>
