<template>
  <section class="space-y-4">
    <slot name="header" />
    <slot />
  </section>
</template>
