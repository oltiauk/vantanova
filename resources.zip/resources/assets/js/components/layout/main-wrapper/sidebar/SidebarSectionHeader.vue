<template>
  <h3 class="uppercase px-6 tracking-widest mb-3">
    <slot />
  </h3>
</template>
