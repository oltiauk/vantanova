export interface RemoteState {
  playable: Playable | null
  volume: number
}
